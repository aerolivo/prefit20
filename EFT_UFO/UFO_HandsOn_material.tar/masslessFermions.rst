(******************************************************************)
(*     Restriction file for SM                                    *)
(*                                                                *)
(*     Set to zero masses and Yukawas for all fermions            *)
(*     except top and bottom quarks                               *)
(******************************************************************)

M$Restrictions = Map[ # -> 0 &, {
	
	(* masses *)

	MU, MD, MC, MS, Me, MMU, MTA,

	(* Yukawas and CKM *)
		
	ymup, ymdo, ymc, yms, yme, ymm, ymtau,
	yu[1,1], yu[2,2], yd[1,1], yd[2,2], yl[_,_],
	
	CKMlambda,
	cabi
}];





