#!/usr/bin/env python
import sys, math, ROOT, array, numpy

def KILL(log):
    print '\n@@@ FATAL -- '+log+'\n'
    raise SystemExit


### main
if __name__ == '__main__':

  
    main_dir = "/home/ilaria/PREFIT_school/"
    file_smin = main_dir + "events_ee.root"


    weights_to_plot = [
           'SM'    # original event wgt
          ,'cHDD'
          ,'cHq1'
          ,'cHu'
          ,'cHl1'
          ,'cHe'
          ,'cqe'
          ,'clq1'
    ]


    ifile_smin = ROOT.TFile.Open(file_smin)

    histo_dc = {
    # histogram settings: xlabel, ylabel, ymin, ymax, y log/lin, ymin panel 2, ymax panel 2, ratio/diff, coefficients to exclude

      'll_mass': ['m_{ll} [GeV]', 
                   "d#sigma/dm_{ll} [pb/40 GeV]",
                   1.05e-1, 3e+2, 'log',
                   .75, 1.17, "ratio",
                   []],
 
      'lp_y'  : ['y_{l^{+}}', 
                 "d#sigma/dy_{l^{+}} [pb]",
                  25, 75, 'lin', 
                  0.2, 2.4, "diff",
                  ["cHq1","cHu","cHd","cqe","clq1"]],
 
      'lm_y'  : ['y_{l^{-}}', 
                 "d#sigma/dy_{l^{-}} [pb]",
                  25, 75, 'lin', 
                  -1, 2., "diff",
                  ["cHq1","cHu","cHd","cqe","clq1"]]
 
     # 'lq_cos'  : ['cos(#theta)', 
     #              "d#sigma/dcos(#theta) [pb]",
     #             15, 50, 'lin', 
     #             -1, 2, "diff"],
      
    }

    color = {
    'SM' :  1,    # black       
    'cHq1': 797, # orange
    'cHu': 824,  # green
    'cHDD': 633, # red
    'cHe': 800,  # yellow
    'cHl1': 430, # azure
    'cqe': 875,  # light gray
    'clq1': 924  # purple
    }


    ROOT.gROOT.SetBatch()
 
    histos = {}

    # get list of weighted histos
    for key in ifile_smin.GetListOfKeys():
        key_name = key.GetTitle()
        histos[key_name] = ifile_smin.Get(key_name)


    for histo_key in histo_dc:

        canvas = ROOT.TCanvas(histo_key, histo_key, 800, 725)

	# histograms pad
	 
        pad1 = ROOT.TPad("histo_pos","histo_pos",0., 0.45, 1, 1)
        pad1.SetTopMargin(0.05)
        pad1.SetBottomMargin(0)
        pad1.SetLeftMargin(0.15)
	pad1.SetGridx()
        if histo_dc[histo_key][4] == 'log':
  	    pad1.SetLogy()
	pad1.Draw()
	pad1.cd()

        leg = ROOT.TLegend(.18,.55,.35,.95)
        
        first_h = True
        for hk in histos.keys():
            coef = hk.split("_")[-1]
            if hk.startswith(histo_key) and coef in weights_to_plot and coef not in histo_dc[histo_key][-1]:
                if first_h:
                   histos[hk].Draw('hist')
                   histos[hk].GetYaxis().SetRangeUser(histo_dc[histo_key][2],histo_dc[histo_key][3])
                   histos[hk].GetYaxis().SetLabelSize(0.05)
                   histos[hk].GetXaxis().SetTitle(histo_dc[histo_key][0])
                   histos[hk].GetXaxis().SetTitleSize(0.05)
                   histos[hk].GetYaxis().SetTitle(histo_dc[histo_key][1])
                   histos[hk].GetYaxis().SetTitleSize(0.05)

	           histos[hk].SetTitle("")
                   first_h = False

                else: 
                   histos[hk].Draw('hist,same')

                histos[hk].SetStats(0)
                histos[hk].SetLineColor(color[coef])
                histos[hk].SetLineWidth(3)
                
                if hk.split("_")[-1].startswith("c"):
                    leg.AddEntry(histos[hk],coef + " = 1")
                else:
                    leg.AddEntry(histos[hk],coef)


        leg.SetTextSize(.035)
        leg.Draw()

        canvas.cd()


        ratio = {}

        for hk in histos.keys():
            coef = hk.split("_")[-1]
            if hk.startswith(histo_key) and not coef == "SM":
                ratio[hk] = histos[hk].Clone()
                # 'ratio' means just normalize to SM
                if histo_dc[histo_key][7]== "ratio":
                    ratio[hk].Divide(histos[histo_key +"_SM"])
                
                # 'diff' means subtract SM, normalize, and take ratio to normalize SM
                # (shape ratio)
                elif histo_dc[histo_key][7]== "diff":
                    ratio[hk].Add(histos[histo_key + "_SM"],-1)
                    ratio[hk].Scale(1/ratio[hk].Integral())
                    h0norm = histos[histo_key+"_SM"].Clone()
                    h0norm.Scale(1/h0norm.Integral())
                    ratio[hk].Divide(h0norm)
                    

        # lower pad: ratio to SM
        pad2 = ROOT.TPad("histo_ratio","histo_ratio",0., 0.0 , 1, 0.45)
        pad2.SetTopMargin(0.0)
        pad2.SetLeftMargin(0.15)
        pad2.SetBottomMargin(0.27)
        pad2.SetGridx()
        pad2.SetGridy()
        #pad2.SetLogy()
        pad2.Draw()
        pad2.cd()


        leg2 = ROOT.TLegend(.6,.3,.9,.65)
        
        first_h = True
        for hk in histos.keys():
            coef = hk.split("_")[-1]
            if hk.startswith(histo_key) and coef in weights_to_plot[1:] and coef not in histo_dc[histo_key][-1] :  
                if first_h:

                    ratio[hk].Draw('hist')
                    ratio[hk].GetYaxis().SetRangeUser(histo_dc[histo_key][5],histo_dc[histo_key][6])
                    ratio[hk].GetXaxis().SetLabelSize(0.05)
                    ratio[hk].GetXaxis().SetLabelOffset(0.015)
                    ratio[hk].GetYaxis().SetLabelSize(0.05)
                    ratio[hk].GetYaxis().SetLabelOffset(0.015)
	            ratio[hk].GetXaxis().SetTitle(histo_dc[histo_key][0])
                    ratio[hk].GetXaxis().SetTitleSize(0.075)
                    if histo_dc[histo_key][7]=="ratio":
	                ratio[hk].GetYaxis().SetTitle("(SM + int.) / SM")
                    elif histo_dc[histo_key][7]=="diff":
	                ratio[hk].GetYaxis().SetTitle("(int./#sigma_{int.}) / (SM/#sigma_{SM})")
                    ratio[hk].GetYaxis().SetTitleSize(0.075)
                    ratio[hk].GetYaxis().SetTitleOffset(0.7)

                    ratio[hk].SetTitle("")
                    first_h=False

                else:
                    ratio[hk].Draw('hist,same')

                ratio[hk].SetLineColor(color[coef])    
                ratio[hk].SetLineStyle(1)
                ratio[hk].SetLineWidth(3)
              
                leg2.AddEntry(ratio[hk], hk,"l")



        leg2.SetTextSize(0.065)
        #leg2.Draw()

        canvas.cd()

	
	canvas.SaveAs("plot_" + histo_key + "_rwgt.pdf")


