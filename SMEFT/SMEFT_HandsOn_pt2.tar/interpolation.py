#!/usr/bin/env python
import sys, math, array, numpy
from scipy.interpolate import interp1d

def KILL(log):
    print '\n@@@ FATAL -- '+log+'\n'
    raise SystemExit

def poly_string(coefs,monom):

    coefs_str = ["%.3e" %coefs[0]]
    for c in coefs[1:]:
        if c > 0 :
           coefs_str.append(" + %.3e " %c)
        elif c < 0:
           coefs_str.append(" - %.3e " %abs(c))
    return "".join([c+m for c,m in zip(coefs_str,monom)])
    

### main
if __name__ == '__main__':

    if len(sys.argv)-1 != 1:
       KILL('two command-line arguments required: [1] input .lhe file, [2] output .root file')

    file_res = file(sys.argv[1], 'r')
    
    values = {}
    

    for line in file_res:
       if line.startswith("#"): continue
 
       
       run, par, xs, err, nevt = line.split()
       
       if not par == "SM":
          coef, val = par.split("_")
       else: 
          coef = "SM"
          val = 1

       if coef in values.keys():
           values[coef].append([float(val),float(xs),float(err)])

       else:
           values.update({coef:[[float(val),float(xs),float(err)]]})
    
        


    fit = {}
    print "\n fit polynomial [pb]"
    for c in values.keys():
        if not c == "SM":

            fit0 = numpy.polyfit([x[0] for x in values[c]],[x[1] for x in values[c]] ,2)
            fit[c] = list(fit0)[::-1] # fit gives (square, int, const) -> reverse
            print poly_string(fit[c],["",c,c+"**2"])


     
    print "\n fit polynomials normalized to SM, c -> (v/Lamdba)^2 c"
    v = 246.22
    Lam = 1000.

    for c in values.keys():
        if not c =="SM":
            fit_norm = fit[c]/fit[c][0] / [1, v**2/Lam**2, v**4/Lam**4] 
            print poly_string(fit_norm,["",c,c+"**2"])


    color = {
    'SM' :  1,    # black       
    'cHq1': 797, # orange
    'cHu': 824,  # green
    'cHDD': 633, # red
    'cHe': 800,  # yellow
    'cHl1': 430, # azure
    'cqe': 875,  # light gray
    'clq1': 924  # purple
    }




  

